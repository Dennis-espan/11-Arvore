# Arvores (continuação)
---

## Objetivos

Ao concluir esta atividade você deverá estender sua compreensão os seguintes conceitos:
* Recursividade
* Estrutura de Dados Arvore
* Arvore Binária



## Atividade Proposta

Faça um fork deste repositorio e realize as seguintes atividades: 

- [ ] Implemente a função buscarElementoArvore que deve verificar se um elemento está contido na arvore usando recursividade
